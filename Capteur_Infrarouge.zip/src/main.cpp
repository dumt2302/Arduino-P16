#include <Arduino.h>
#include <LibRobus.h>

void testDistance();
float distance(int);

// Variable
int valDeRetour = 0;

void setup() 
{
  Serial.begin(9600);
  BoardInit();
}

void loop() {
  testDistance();
}

void testDistance()
{
  valDeRetour = ROBUS_ReadIR(1);
  delay(100);
  Serial.print(valDeRetour);
  Serial.print(F(" - "));
  delay(100);
  Serial.println(distance(valDeRetour));

  if(valDeRetour < 200)
  {
    Serial.println(F("Obstacle d'etecté"));
  }

}

float distance(int valeurBrute)
{
  float VoltageSortie = float(valeurBrute) * (5/1023);

  float relDistance = (0.0485/(VoltageSortie - 0.74875)) - 0.42;
  //ou
  /*float relDistance = 200.3775040589502
            - 2.2657665648980 * VoltageSortie
            + 0.0116395328796 * VoltageSortie * VoltageSortie
            - 0.0000299194195 * VoltageSortie * VoltageSortie * VoltageSortie
            + 0.0000000374087 * VoltageSortie * VoltageSortie * VoltageSortie * VoltageSortie
            - 0.0000000000181 * VoltageSortie * VoltageSortie * VoltageSortie * VoltageSortie * VoltageSortie;*/
  //float relDistance = 13 * pow(VoltageSortie, -1);
  return relDistance;
}